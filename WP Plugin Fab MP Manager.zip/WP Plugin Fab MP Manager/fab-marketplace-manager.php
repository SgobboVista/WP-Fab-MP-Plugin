<?php
/*
Plugin Name: Fab MP Manager
Description: Manage your Fab MP articles directly in WordPress.
Version: 2.1.5
Author: SgobboVista
Requires at least: 5.8.1
*/

if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function () {
        echo '<div class="error"><p><strong>' . __('Fab MPM Manager', 'fab-mpm-manager') . '</strong> ' . __('requires PHP version 7.4 or higher. Please update your PHP version.', 'fab-mpm-manager') . '</p></div>';
    });
    deactivate_plugins(plugin_basename(__FILE__));
    return;
}

add_action('admin_menu', 'fab_mpm_add_admin_menu');
function fab_mpm_add_admin_menu() {
    add_menu_page(
        __('Fab MPM Manager', 'fab-mpm-manager'),
        __('Fab MPM', 'fab-mpm-manager'),
        'manage_options',
        'fab-mpm',
        'fab_mpm_admin_page',
        'dashicons-store',
        20
    );

    add_submenu_page(
        null,
        __('Add Article', 'fab-mpm-manager'),
        __('Add Article', 'fab-mpm-manager')
        'manage_options',
        'fab-mpm-add-article',
        'fab_mpm_add_article_page'
    );

    add_submenu_page(
        null,
        __('Edit Article', 'fab-mpm-manager'),
        __('Edit Article', 'fab-mpm-manager'),
        'manage_options',
        'fab-mpm-edit-article',
        'fab_mpm_edit_article_page'
    );
}

register_activation_hook(__FILE__, 'fab_mpm_check_and_create_table');

function fab_mpm_check_and_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fab_articles';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
        fab_mpm_create_table();
    }
}

function fab_mpm_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fab_articles';
    $charset_collate = "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";

    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        article_id VARCHAR(14) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        pack_name_internal VARCHAR(255) DEFAULT NULL,
        number_of_assets INT DEFAULT 0,
        private_price DECIMAL(10, 2) DEFAULT NULL,
        professional_price DECIMAL(10, 2) DEFAULT NULL,
        process VARCHAR(255) DEFAULT NULL,
        rejection_reason TEXT DEFAULT NULL,
        notes TEXT DEFAULT NULL,
        category VARCHAR(255) DEFAULT NULL,
        image_url TEXT DEFAULT NULL,
        external_url TEXT DEFAULT NULL,
        creation_year INT NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function fab_mpm_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'fab_articles';

    $search_query = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    $orderby = isset($_GET['orderby']) ? sanitize_text_field($_GET['orderby']) : 'name';
    $order = isset($_GET['order']) && in_array(strtolower($_GET['order']), ['asc', 'desc']) ? strtoupper($_GET['order']) : 'ASC';

    $sql = "SELECT * FROM $table_name";
    if (!empty($search_query)) {
        $sql .= $wpdb->prepare(" WHERE name LIKE %s OR category LIKE %s", '%' . $search_query . '%', '%' . $search_query . '%');
    }
    $sql .= " ORDER BY $orderby $order";

    $articles = $wpdb->get_results($sql);

    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">' . __('Fab MPM Manager', 'fab-mpm-manager') . '</h1>';
    echo '<hr class="wp-header-end">';

    echo '<form method="GET" action="">';
    echo '<input type="hidden" name="page" value="fab-mpm">';
    echo '<p class="search-box">';
    echo '<label class="screen-reader-text" for="post-search-input">' . __('Search Articles', 'fab-mpm-manager') . '</label>';
    echo '<input type="search" id="post-search-input" name="s" value="' . esc_attr($search_query) . '">';
    echo '<input type="submit" class="button" value="' . __('Search', 'fab-mpm-manager') . '">';
    echo '</p>';
    echo '</form>';

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'article_id', 'order' => ($orderby === 'article_id' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Article ID', 'fab-mpm-manager') . '</a></th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'name', 'order' => ($orderby === 'name' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Name', 'fab-mpm-manager') . '</a></th>';
    echo '<th>' . __('Pack Name Internal', 'fab-mpm-manager') . '</th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'number_of_assets', 'order' => ($orderby === 'number_of_assets' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Number of Assets', 'fab-mpm-manager') . '</a></th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'private_price', 'order' => ($orderby === 'private_price' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Price in $ (Private)', 'fab-mpm-manager') . '</a></th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'professional_price', 'order' => ($orderby === 'professional_price' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Price in $ (Professional)', 'fab-mpm-manager') . '</a></th>';
    echo '<th>' . __('Process', 'fab-mpm-manager') . '</th>';
    echo '<th>' . __('Rejection Reason', 'fab-mpm-manager') . '</th>';
    echo '<th>' . __('Notes', 'fab-mpm-manager') . '</th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'category', 'order' => ($orderby === 'category' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Category', 'fab-mpm-manager') . '</a></th>';
    echo '<th>' . __('Image', 'fab-mpm-manager') . '</th>';
    echo '<th>' . __('External URL', 'fab-mpm-manager') . '</th>';
    echo '<th><a href="' . add_query_arg(['orderby' => 'creation_year', 'order' => ($orderby === 'creation_year' && $order === 'ASC') ? 'desc' : 'asc']) . '">' . __('Creation Year', 'fab-mpm-manager') . '</a></th>';
    echo '<th>' . __('Actions', 'fab-mpm-manager') . '</th>';
    echo '</tr></thead>';
    echo '<tbody>';
    if (empty($articles)) {
        echo '<tr><td colspan="14">' . __('No articles to display.', 'fab-mpm-manager') . '</td></tr>';
    } else {
        foreach ($articles as $article) {
            echo '<tr>';
            echo '<td>' . $article->article_id . '</td>';
            echo '<td>' . $article->name . '</td>';
            echo '<td>' . $article->pack_name_internal . '</td>';
            echo '<td>' . $article->number_of_assets . '</td>';
            echo '<td>' . $article->private_price . '</td>';
            echo '<td>' . $article->professional_price . '</td>';
            echo '<td>' . $article->process . '</td>';
            echo '<td>' . $article->rejection_reason . '</td>';
            echo '<td>' . $article->notes . '</td>';
            echo '<td>' . $article->category . '</td>';
            echo '<td>' . ($article->image_url ? '<img src="' . esc_url($article->image_url) . '" width="50">' : __('No Image', 'fab-mpm-manager')) . '</td>';
            echo '<td>' . ($article->external_url ? '<a href="' . esc_url($article->external_url) . '" target="_blank">' . __('Open Link', 'fab-mpm-manager') . '</a>' : __('No URL', 'fab-mpm-manager')) . '</td>';
            echo '<td>' . $article->creation_year . '</td>';
            echo '<td>';
            echo '<a href="' . admin_url('admin.php?page=fab-mpm-edit-article&edit_id=' . $article->id) . '" class="button button-primary">' . __('Edit', 'fab-mpm-manager') . '</a> ';
            echo '<form method="POST" style="display:inline;">';
            echo '<input type="hidden" name="id" value="' . $article->id . '">';
            echo '<button type="submit" name="delete_article" class="button button-danger" onclick="return confirm(\'' . __('Are you sure you want to delete this article?', 'fab-mpm-manager') . '\');">' . __('Delete', 'fab-mpm-manager') . '</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}

function fab_mpm_add_article_page() {
    echo '<div class="wrap">';
    echo '<h1>' . __('Add Article', 'fab-mpm-manager') . '</h1>';
    echo '<form method="POST" action="' . admin_url('admin.php?page=fab-mpm') . '">';
    echo '<table class="form-table">';
    echo '<tr><th><label for="name">' . __('Name', 'fab-mpm-manager') . '</label></th><td><input type="text" id="name" name="name" class="regular-text" required></td></tr>';
    echo '<tr><th><label for="pack_name_internal">' . __('Pack Name Internal', 'fab-mpm-manager') . '</label></th><td><input type="text" id="pack_name_internal" name="pack_name_internal" class="regular-text"></td></tr>';
    echo '<tr><th><label for="number_of_assets">' . __('Number of Assets', 'fab-mpm-manager') . '</label></th><td><input type="number" id="number_of_assets" name="number_of_assets" class="small-text"></td></tr>';
    echo '<tr><th><label for="private_price">' . __('Price (Private)', 'fab-mpm-manager') . '</label></th><td><input type="number" id="private_price" name="private_price" step="0.01" class="small-text"></td></tr>';
    echo '<tr><th><label for="professional_price">' . __('Price (Professional)', 'fab-mpm-manager') . '</label></th><td><input type="number" id="professional_price" name="professional_price" step="0.01" class="small-text"></td></tr>';
    echo '<tr><th><label for="process">' . __('Process', 'fab-mpm-manager') . '</label></th><td>';
    echo '<select id="process" name="process">';
    $process_options = ['In Progress', 'Approved', 'Rejected', 'Changes Needed'];
    foreach ($process_options as $option) {
        echo '<option value="' . esc_attr($option) . '">' . esc_html__($option, 'fab-mpm-manager') . '</option>';
    }
    echo '</select>';
    echo '</td></tr>';
    echo '<tr><th><label for="rejection_reason">' . __('Rejection Reason', 'fab-mpm-manager') . '</label></th><td><textarea id="rejection_reason" name="rejection_reason" class="large-text"></textarea></td></tr>';
    echo '<tr><th><label for="notes">' . __('Notes', 'fab-mpm-manager') . '</label></th><td><textarea id="notes" name="notes" class="large-text"></textarea></td></tr>';
    echo '<tr><th><label for="category">' . __('Category', 'fab-mpm-manager') . '</label></th><td>';
    echo '<select id="category" name="category">';
    $categories = ['3D', 'Environments', 'Materials & Textures', 'Sprites and Flipbooks', 'Stickers', 'Brushes', 'HDRI', 'Animations', 'Audio', 'VFX', 'UI', 'Game Systems', 'Game Templates', 'Tools & Plugins', 'Education & Tutorials'];
    foreach ($categories as $category) {
        echo '<option value="' . esc_attr($category) . '">' . esc_html__($category, 'fab-mpm-manager') . '</option>';
    }
    echo '</select>';
    echo '</td></tr>';
    echo '<tr><th><label for="image_url">' . __('Image URL', 'fab-mpm-manager') . '</label></th><td><input type="text" id="image_url" name="image_url" class="regular-text"></td></tr>';
    echo '<tr><th><label for="external_url">' . __('External URL', 'fab-mpm-manager') . '</label></th><td><input type="url" id="external_url" name="external_url" class="regular-text"></td></tr>';
    echo '</table>';
    echo '<p class="submit">';
    echo '<button type="submit" name="add_article" class="button button-primary">' . __('Add Article', 'fab-mpm-manager') . '</button>';
    echo '<a href="' . admin_url('admin.php?page=fab-mpm') . '" class="button button-secondary" style="margin-left: 10px;">' . __('Back', 'fab-mpm-manager') . '</a>';
    echo '</p>';
    echo '</form>';
    echo '</div>';
}
?>
